#!/bin/sh
sysrepod
# execute docker command
exec "$@"
