---
name: Feature request
about: Suggest an idea for this project

---

**This is to suggest improvements to the `P4Runtime` specification. For issues regarding a specific implementation, please open an issue with the appropriate repository (e.g. https://github.com/p4lang/behavioral-model or https://github.com/p4lang/PI for bmv2).**
